import os, sqlite3, asyncio
from werkzeug.security import generate_password_hash

DB_PATH = 'dramaforge.db'

def init():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0,
        suno_api_key TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        genre TEXT,
        concept TEXT,
        episode_count INTEGER DEFAULT 48,
        status TEXT DEFAULT 'draft',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')
    c.execute('''CREATE TABLE characters (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        role TEXT,
        age TEXT,
        description TEXT,
        prompt_tokens TEXT,
        portrait_path TEXT,
        seed INTEGER,
        voice_gender TEXT DEFAULT 'female',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id)
    )''')
    c.execute('''CREATE TABLE episodes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        ep_number INTEGER NOT NULL,
        title TEXT,
        script_text TEXT,
        music_path TEXT,
        status TEXT DEFAULT 'draft',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id)
    )''')
    c.execute('''CREATE TABLE scenes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        episode_id INTEGER NOT NULL,
        scene_number INTEGER NOT NULL,
        prompt TEXT,
        image_path TEXT,
        tts_path TEXT,
        animation_type TEXT DEFAULT 'kenburns',
        duration INTEGER DEFAULT 6000,
        text_overlay TEXT,
        voice_text TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (episode_id) REFERENCES episodes(id)
    )''')
    c.execute('''CREATE TABLE videos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        episode_id INTEGER,
        file_path TEXT,
        status TEXT DEFAULT 'ready',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute("INSERT INTO users (username, password_hash, is_admin) VALUES (?,?,?)",
              ('admin', generate_password_hash('admin123'), 1))
    conn.commit()
    conn.close()
    print("Database initialized. Admin: admin / admin123")

if __name__ == '__main__':
    init()
