import os, sqlite3, requests, urllib.parse, random, asyncio, edge_tts
from functools import wraps
from flask import (Flask, render_template, request, redirect, url_for,
                   flash, g, jsonify, session, send_file)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dramaforge-secret-dev-key-CHANGE-ME')
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024
DATABASE = 'dramaforge.db'
UPLOAD = 'static/uploads'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

def execute_db(query, args=()):
    db = get_db()
    cur = db.execute(query, args)
    db.commit()
    return cur.lastrowid

# ── Auth ──
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        u = query_db('SELECT * FROM users WHERE id=?', (session['user_id'],), one=True)
        if not u or not u['is_admin']:
            flash('Admin access required')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated

# ── Public ──
@app.route('/')
def index():
    published = query_db("SELECT p.*, u.username FROM projects p JOIN users u ON p.user_id=u.id WHERE p.status='published' ORDER BY p.created_at DESC")
    return render_template('index.html', projects=published)

@app.route('/watch/<int:project_id>/<int:ep_number>')
def watch(project_id, ep_number):
    project = query_db('SELECT p.*, u.username FROM projects p JOIN users u ON p.user_id=u.id WHERE p.id=?', (project_id,), one=True)
    episode = query_db('SELECT * FROM episodes WHERE project_id=? AND ep_number=?', (project_id, ep_number), one=True)
    if not episode:
        flash('Episode not found')
        return redirect(url_for('index'))
    scenes = query_db('SELECT * FROM scenes WHERE episode_id=? ORDER BY scene_number', (episode['id'],))
    video = query_db('SELECT * FROM videos WHERE episode_id=?', (episode['id'],), one=True)
    prev_ep = query_db('SELECT ep_number FROM episodes WHERE project_id=? AND ep_number<? ORDER BY ep_number DESC', (project_id, ep_number), one=True)
    next_ep = query_db('SELECT ep_number FROM episodes WHERE project_id=? AND ep_number>? ORDER BY ep_number ASC', (project_id, ep_number), one=True)
    return render_template('watch.html', project=project, episode=episode, scenes=scenes, video=video, prev_ep=prev_ep, next_ep=next_ep)

# ── Auth routes ──
@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        u = request.form['username'].strip()
        p = request.form['password']
        if not u or not p:
            flash('Fill all fields')
            return redirect(url_for('register'))
        existing = query_db('SELECT id FROM users WHERE username=?', (u,), one=True)
        if existing:
            flash('Username taken')
            return redirect(url_for('register'))
        execute_db('INSERT INTO users (username, password_hash) VALUES (?,?)',
                   (u, generate_password_hash(p)))
        flash('Account created. Please log in.')
        return redirect(url_for('login'))
    return render_template('login.html', mode='register')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        u = request.form['username'].strip()
        p = request.form['password']
        user = query_db('SELECT * FROM users WHERE username=?', (u,), one=True)
        if user and check_password_hash(user['password_hash'], p):
            session['user_id'] = user['id']
            session['username'] = user['username']
            return redirect(url_for('studio'))
        flash('Invalid credentials')
        return redirect(url_for('login'))
    return render_template('login.html', mode='login')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# ── Studio ──
@app.route('/studio')
@login_required
def studio():
    projects = query_db('SELECT * FROM projects WHERE user_id=? ORDER BY created_at DESC', (session['user_id'],))
    return render_template('studio.html', projects=projects)

@app.route('/studio/project', methods=['POST'])
@login_required
def create_project():
    title = request.form['title'].strip()
    genre = request.form.get('genre','')
    concept = request.form.get('concept','')
    ep_count = int(request.form.get('episode_count', 48))
    pid = execute_db('INSERT INTO projects (user_id, title, genre, concept, episode_count) VALUES (?,?,?,?,?)',
                     (session['user_id'], title, genre, concept, ep_count))
    for i in range(1, ep_count+1):
        execute_db('INSERT INTO episodes (project_id, ep_number, title) VALUES (?,?,?)', (pid, i, f'Episode {i}'))
    flash('Project created')
    return redirect(url_for('project', project_id=pid))

@app.route('/studio/project/<int:project_id>')
@login_required
def project(project_id):
    p = query_db('SELECT * FROM projects WHERE id=? AND user_id=?', (project_id, session['user_id']), one=True)
    if not p:
        flash('Not found')
        return redirect(url_for('studio'))
    characters = query_db('SELECT * FROM characters WHERE project_id=?', (project_id,))
    episodes = query_db('SELECT * FROM episodes WHERE project_id=? ORDER BY ep_number', (project_id,))
    return render_template('project.html', project=p, characters=characters, episodes=episodes)

@app.route('/studio/episode/<int:episode_id>')
@login_required
def episode(episode_id):
    ep = query_db('SELECT e.*, p.user_id, p.title as project_title FROM episodes e JOIN projects p ON e.project_id=p.id WHERE e.id=?', (episode_id,), one=True)
    if not ep or ep['user_id'] != session['user_id']:
        flash('Not found')
        return redirect(url_for('studio'))
    scenes = query_db('SELECT * FROM scenes WHERE episode_id=? ORDER BY scene_number', (episode_id,))
    characters = query_db('SELECT * FROM characters WHERE project_id=?', (ep['project_id'],))
    video = query_db('SELECT * FROM videos WHERE episode_id=?', (episode_id,), one=True)
    return render_template('episode.html', episode=ep, scenes=scenes, characters=characters, video=video)

# ── API: Pollinations text proxy ──
@app.route('/api/generate-script', methods=['POST'])
@login_required
def generate_script():
    data = request.get_json()
    concept = data.get('concept','')
    style = data.get('style','dramatic short drama, heavy cliffhanger')
    prompt = f"Write a 60-second vertical short drama episode. Concept: {concept}. Style: {style}. Format: Narration with scene descriptions. Under 160 words. Do not use markdown headings. Just flowing script text."
    url = f"https://text.pollinations.ai/{urllib.parse.quote(prompt)}?seed={random.randint(1,999999)}"
    try:
        r = requests.get(url, timeout=30)
        txt = r.text.strip()
        return jsonify({'script': txt})
    except Exception as e:
        return jsonify({'script': f'Error: {str(e)}'}), 500

# ── API: Character portrait via Pollinations image ──
@app.route('/api/character/generate', methods=['POST'])
@login_required
def generate_character():
    data = request.get_json()
    project_id = data['project_id']
    name = data['name']
    desc = data.get('description','')
    prompt_core = data.get('prompt_tokens','')
    seed = int(data.get('seed', random.randint(1,999999)))
    gender = data.get('voice_gender','female')
    full_prompt = f"Cinematic vertical portrait of {name}, {desc}. {prompt_core}. Fashion editorial photography, sharp focus, dramatic lighting, 8k, 9:16 vertical format, raw style"
    img_url = f"https://image.pollinations.ai/prompt/{urllib.parse.quote(full_prompt)}?width=512&height=768&seed={seed}&nologo=true"
    try:
        r = requests.get(img_url, timeout=60)
        if r.status_code == 200:
            filename = f"portraits/p_{project_id}_{name.replace(' ','_').lower()}_{random.randint(1000,9999)}.png"
            filepath = os.path.join(UPLOAD, filename)
            with open(filepath, 'wb') as f:
                f.write(r.content)
            cid = execute_db('INSERT INTO characters (project_id, name, role, age, description, prompt_tokens, portrait_path, seed, voice_gender) VALUES (?,?,?,?,?,?,?,?,?)',
                (project_id, name, data.get('role',''), data.get('age',''), desc, prompt_core, filename, seed, gender))
            return jsonify({'id': cid, 'portrait_url': f'/{UPLOAD}/{filename}', 'seed': seed})
        return jsonify({'error': 'Image generation failed'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ── API: Scene image via Pollinations ──
@app.route('/api/scene/generate', methods=['POST'])
@login_required
def generate_scene():
    data = request.get_json()
    episode_id = data['episode_id']
    scene_num = data['scene_number']
    desc = data.get('description','')
    style = data.get('style','cinematic vertical shot, 35mm lens, film grain, dramatic lighting, raw style')
    duration = int(data.get('duration', 6000))
    text_overlay = data.get('text_overlay','')
    voice_text = data.get('voice_text','')
    ep = query_db('SELECT project_id FROM episodes WHERE id=?', (episode_id,), one=True)
    if not ep:
        return jsonify({'error':'episode not found'}), 404
    chars = query_db('SELECT * FROM characters WHERE project_id=?', (ep['project_id'],))
    prompt = desc
    for c in chars:
        if c['name'].lower() in desc.lower():
            prompt = f"{c['prompt_tokens']}. {prompt}"
    full = f"{prompt}. {style}"
    img_url = f"https://image.pollinations.ai/prompt/{urllib.parse.quote(full)}?width=512&height=768&seed={random.randint(1,999999)}&nologo=true"
    try:
        r = requests.get(img_url, timeout=60)
        if r.status_code == 200:
            filename = f"scenes/e_{episode_id}_s_{scene_num}_{random.randint(1000,9999)}.png"
            filepath = os.path.join(UPLOAD, filename)
            with open(filepath, 'wb') as f:
                f.write(r.content)
            sid = execute_db('INSERT INTO scenes (episode_id, scene_number, prompt, image_path, duration, text_overlay, voice_text) VALUES (?,?,?,?,?,?,?)',
                (episode_id, scene_num, full, filename, duration, text_overlay, voice_text))
            return jsonify({'id': sid, 'image_url': f'/{UPLOAD}/{filename}', 'prompt': full})
        return jsonify({'error':'Image generation failed'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/scene/<int:scene_id>', methods=['POST'])
@login_required
def update_scene(scene_id):
    data = request.get_json()
    fields = []
    vals = []
    for k in ['duration','text_overlay','voice_text','animation_type']:
        if k in data:
            fields.append(f"{k}=?")
            vals.append(data[k])
    if not fields:
        return jsonify({'ok':True})
    vals.append(scene_id)
    execute_db(f"UPDATE scenes SET {', '.join(fields)} WHERE id=?", vals)
    return jsonify({'ok':True})

@app.route('/api/episode/<int:episode_id>/scenes')
@login_required
def get_scenes(episode_id):
    scenes = query_db('SELECT * FROM scenes WHERE episode_id=? ORDER BY scene_number', (episode_id,))
    return jsonify([dict(s) for s in scenes])

@app.route('/api/episode/<int:episode_id>/script', methods=['POST'])
@login_required
def save_script(episode_id):
    data = request.get_json()
    execute_db('UPDATE episodes SET script_text=?, title=? WHERE id=?',
               (data.get('script_text',''), data.get('title',''), episode_id))
    return jsonify({'ok':True})

@app.route('/api/project/<int:project_id>/publish', methods=['POST'])
@login_required
def publish_project(project_id):
    p = query_db('SELECT * FROM projects WHERE id=? AND user_id=?', (project_id, session['user_id']), one=True)
    if not p:
        return jsonify({'error':'not found'}), 404
    new_status = 'published' if p['status'] != 'published' else 'draft'
    execute_db('UPDATE projects SET status=? WHERE id=?', (new_status, project_id))
    return jsonify({'status': new_status})

# ── Upload composed video ──
@app.route('/api/upload-video', methods=['POST'])
@login_required
def upload_video():
    episode_id = request.form.get('episode_id')
    file = request.files.get('video')
    if not file or not episode_id:
        return jsonify({'error':'missing data'}), 400
    ep = query_db('SELECT project_id FROM episodes WHERE id=?', (episode_id,), one=True)
    if not ep:
        return jsonify({'error':'episode not found'}), 404
    ext = file.filename.split('.')[-1] if '.' in file.filename else 'webm'
    filename = f"videos/e_{episode_id}_{random.randint(1000,9999)}.{ext}"
    filepath = os.path.join(UPLOAD, filename)
    file.save(filepath)
    old = query_db('SELECT id FROM videos WHERE episode_id=?', (episode_id,), one=True)
    if old:
        execute_db('DELETE FROM videos WHERE id=?', (old['id'],))
    vid = execute_db('INSERT INTO videos (project_id, episode_id, file_path) VALUES (?,?,?)',
                     (ep['project_id'], episode_id, filename))
    return jsonify({'video_url': f'/{UPLOAD}/{filename}'})

# ── NEW: TTS Generation via edge-tts (FREE, no API key) ──
def tts_sync(text, out_path, voice="en-US-AriaNeural"):
    async def _run():
        communicate = edge_tts.Communicate(text, voice)
        await communicate.save(out_path)
    asyncio.run(_run())

@app.route('/api/episode/<int:episode_id>/generate-tts', methods=['POST'])
@login_required
def generate_tts_for_episode(episode_id):
    ep = query_db('SELECT e.*, p.user_id FROM episodes e JOIN projects p ON e.project_id=p.id WHERE e.id=?', (episode_id,), one=True)
    if not ep or ep['user_id'] != session['user_id']:
        return jsonify({'error':'not found'}), 404
    scenes = query_db('SELECT * FROM scenes WHERE episode_id=? ORDER BY scene_number', (episode_id,))
    results = []
    for s in scenes:
        if not s['voice_text']:
            continue
        tts_dir = os.path.join(UPLOAD, 'tts')
        os.makedirs(tts_dir, exist_ok=True)
        tts_name = f"e_{episode_id}_s_{s['scene_number']}_{random.randint(1000,9999)}.mp3"
        tts_path = os.path.join(tts_dir, tts_name)
        try:
            tts_sync(s['voice_text'], tts_path)
            db_path = f"tts/{tts_name}"
            execute_db('UPDATE scenes SET tts_path=? WHERE id=?', (db_path, s['id']))
            results.append({'scene': s['scene_number'], 'tts': f'/{UPLOAD}/{db_path}'})
        except Exception as e:
            results.append({'scene': s['scene_number'], 'error': str(e)})
    return jsonify({'generated': results})

@app.route('/api/episode/<int:episode_id>/tts-status')
@login_required
def tts_status(episode_id):
    ep = query_db('SELECT e.*, p.user_id FROM episodes e JOIN projects p ON e.project_id=p.id WHERE e.id=?', (episode_id,), one=True)
    if not ep or ep['user_id'] != session['user_id']:
        return jsonify({'error':'not found'}), 404
    scenes = query_db('SELECT id, scene_number, voice_text, tts_path FROM scenes WHERE episode_id=? ORDER BY scene_number', (episode_id,))
    return jsonify({'scenes': [dict(s) for s in scenes], 'music': ep['music_path']})

# ── NEW: Upload background music ──
@app.route('/api/episode/<int:episode_id>/upload-music', methods=['POST'])
@login_required
def upload_music(episode_id):
    ep = query_db('SELECT e.*, p.user_id FROM episodes e JOIN projects p ON e.project_id=p.id WHERE e.id=?', (episode_id,), one=True)
    if not ep or ep['user_id'] != session['user_id']:
        return jsonify({'error':'not found'}), 404
    file = request.files.get('music')
    if not file:
        return jsonify({'error':'no file'}), 400
    ext = file.filename.split('.')[-1] if '.' in file.filename else 'mp3'
    if ext.lower() not in ['mp3','wav','ogg','m4a']:
        return jsonify({'error':'invalid format'}), 400
    music_dir = os.path.join(UPLOAD, 'music')
    os.makedirs(music_dir, exist_ok=True)
    filename = f"e_{episode_id}_music_{random.randint(1000,9999)}.{ext}"
    filepath = os.path.join(music_dir, filename)
    file.save(filepath)
    db_path = f"music/{filename}"
    execute_db('UPDATE episodes SET music_path=? WHERE id=?', (db_path, episode_id))
    return jsonify({'music_url': f'/{UPLOAD}/{db_path}'})

# ── NEW: Suno API proxy ──
@app.route('/api/suno/generate', methods=['POST'])
@login_required
def suno_generate():
    data = request.get_json()
    prompt = data.get('prompt','')
    api_key = data.get('api_key','')
    if not api_key:
        return jsonify({'error':'Suno API key required. Get one at https://suno.com. Suno offers a free tier with credits for new accounts.'}), 400
    try:
        # Suno API v1 endpoint (may evolve; adjust as needed)
        r = requests.post('https://studio-api.suno.ai/api/tts/generate',
                          headers={'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'},
                          json={'prompt': prompt, 'model': 'chirp-v3-0', 'make_instrumental': True},
                          timeout=60)
        return jsonify(r.json()), r.status_code
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ── Admin ──
@app.route('/admin')
@admin_required
def admin_dashboard():
    stats = {
        'users': query_db('SELECT COUNT(*) as c FROM users', one=True)['c'],
        'projects': query_db('SELECT COUNT(*) as c FROM projects', one=True)['c'],
        'episodes': query_db('SELECT COUNT(*) as c FROM episodes', one=True)['c'],
        'scenes': query_db('SELECT COUNT(*) as c FROM scenes', one=True)['c'],
        'videos': query_db('SELECT COUNT(*) as c FROM videos', one=True)['c'],
    }
    users = query_db('SELECT u.*, COUNT(p.id) as project_count FROM users u LEFT JOIN projects p ON u.id=p.user_id GROUP BY u.id')
    recent_projects = query_db('SELECT p.*, u.username FROM projects p JOIN users u ON p.user_id=u.id ORDER BY p.created_at DESC LIMIT 20')
    return render_template('admin.html', stats=stats, users=users, projects=recent_projects)

@app.route('/api/admin/stats')
@admin_required
def admin_stats():
    daily = query_db("SELECT DATE(created_at) as d, COUNT(*) as c FROM projects GROUP BY DATE(created_at) ORDER BY d DESC LIMIT 14")
    return jsonify({
        'daily': [dict(x) for x in daily],
        'totals': {
            'users': query_db('SELECT COUNT(*) as c FROM users', one=True)['c'],
            'published': query_db("SELECT COUNT(*) as c FROM projects WHERE status='published'", one=True)['c']
        }
    })

# ── Static helpers ──
@app.route('/static/uploads/<path:filename>')
def uploaded_file(filename):
    return send_file(os.path.join(UPLOAD, filename))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
