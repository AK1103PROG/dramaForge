# Deploy DramaForge to the Internet (Free)
## Get Your Two Real Links: Public + Admin

---

## WHAT YOU GET AFTER THIS

Two live website links that work from any phone or computer:
- **Public link:** `https://dramaforge-xyz.onrender.com/` — anyone can watch dramas
- **Admin link:** `https://dramaforge-xyz.onrender.com/admin` — your dashboard
- **Studio link:** `https://dramaforge-xyz.onrender.com/studio` — creator tools

Login: `admin` / `admin123` (change this immediately after setup)

---

## STEP 1: PUT THE CODE ON GITHUB (2 minutes)

You need a free GitHub account to act as the storage box.

1. Go to **github.com** and sign up (free, takes 30 seconds).
2. Click the **+** button (top right) → **New repository**.
3. Name it: `dramaforge`
4. Choose **Public** or **Private** (doesn't matter).
5. Leave everything else blank. Click **Create repository**.
6. You now see a page with a green button that says **"<> Code"**. Click it.
7. Switch to the **"Uploading an existing file?"** link below the big green button and click it.
8. Now open the `dramaforge` folder on your computer (the one you downloaded from the workspace).
9. **Drag and drop ALL the files and folders** from inside the `dramaforge` folder into the GitHub upload area.
10. Scroll down and click **Commit changes**.

✅ Done. Your code is now stored on GitHub.

---

## STEP 2: CONNECT TO RENDER.COM (3 minutes)

Render is a free service that turns your code into a live website.

1. Go to **render.com** and sign up with your **GitHub account** (click "Sign up with GitHub" — this connects them automatically).
2. On the Render dashboard, click the big blue button: **New +**
3. Choose **Web Service**.
4. Render shows you your GitHub repositories. Find **dramaforge** and click **Connect**.
5. Fill in these exact fields:

| Field | What to type |
|-------|-------------|
| **Name** | `dramaforge` |
| **Region** | Choose the one closest to you |
| **Runtime** | `Python 3` |
| **Branch** | `main` (or `master` if that's what you see) |
| **Build Command** | `pip install -r requirements.txt && python init_db.py` |
| **Start Command** | `gunicorn -w 2 -b 0.0.0.0:10000 app:app` |
| **Plan** | `Free` |

6. Click **Advanced** and add one Environment Variable:
   - Key: `SECRET_KEY`
   - Value: type any random long sentence (example: `my-super-secret-drama-key-2026-never-guess`)
7. Click **Create Web Service**.

Render will now build your website. Wait 2–3 minutes. You will see a green checkmark ✅ when it's live.

8. At the top of the page, you see a URL that looks like:
   `https://dramaforge-abc123.onrender.com`
   
   **This is your public link. Bookmark it.**

---

## STEP 3: OPEN YOUR TWO LINKS

| Link | Address |
|------|---------|
| Public Gallery | `https://dramaforge-abc123.onrender.com/` |
| Creator Studio | `https://dramaforge-abc123.onrender.com/studio` |
| Admin Dashboard | `https://dramaforge-abc123.onrender.com/admin` |

**First login:**
- Go to `/login`
- Username: `admin`
- Password: `admin123`
- Click **Log In**

You are now inside the studio. You can start creating dramas immediately.

---

## STEP 4: LET OTHER PEOPLE USE IT (Free users)

1. Give people the **Public Gallery link** (`https://dramaforge-abc123.onrender.com/`).
2. They can watch published episodes for free.
3. If they want to create their own dramas, they click **Start Creating Free** and register.
4. Everyone gets their own studio dashboard.

---

## STEP 5: HOW YOU EARN MONEY (Monetization)

The free Render plan lets you prove the concept. To earn money, add these layers:

### Method A: Paywall Episodes (Simplest)
- Episodes 1–3 are free (the hook).
- Episodes 4+ require payment.
- Add a Stripe "Pay $2.99 to unlock Episode 4" button inside the watch page.
- You keep 100% of the money. Stripe takes 2.9% + $0.30.

### Method B: Monthly Creator Subscription
- Free plan: 1 project, 12 episodes max.
- Pro plan ($9.99/month via Stripe/PayPal): unlimited episodes, HD export, custom music.
- Add a "Upgrade to Pro" button in the studio.

### Method C: Revenue Share from Platforms
- Export videos from DramaForge.
- Upload to Netshort / ReelShort / DramaBox.
- They pay you per minute watched (see PUBLISHING_GUIDE.md).

### Method D: Ad Revenue on Your Own Site
- Add Google AdSense banners to the Public Gallery.
- Every visitor earns you a fraction of a penny. At 10,000 visitors/day = $15–$40/day.

---

## IMPORTANT: DATABASE ON FREE RENDER

The free Render plan **resets the database** when the server sleeps (after 15 minutes of no traffic).

**Fix this in 30 seconds:**
1. In your Render dashboard, click your service.
2. Go to **Settings** → **Environment**.
3. Add a **Persistant Disk**:
   - Name: `data`
   - Mount Path: `/opt/render/project/src`
   - Size: `1 GB` (free tier max)
4. Click **Save Changes**.
5. In **Build Command**, change to:
   ```
   pip install -r requirements.txt
   ```
   (Remove the `&& python init_db.py` part after the first deploy — otherwise it resets every time.)

Now user accounts and projects will survive forever.

---

## TROUBLESHOOTING

| Problem | Fix |
|---------|-----|
| "Build failed" on Render | Check that `requirements.txt` is in the root folder of your GitHub repo |
| "No module named Flask" | The build command didn't run. Click "Manual Deploy" → "Clear build cache & deploy" |
| Database keeps resetting | You didn't add the disk. Follow Step "Persistant Disk" above |
| Images don't load | The `static/uploads` folder wasn't created. It auto-creates on first upload. If not, add an empty file called `.gitkeep` inside `static/uploads/portraits`, `scenes`, `videos` |
| Site is slow | Free Render servers sleep after 15 min. First visit after sleeping takes 30 seconds to wake up. This is normal. |

---

## ALTERNATIVE: REPLIT (Even Faster, 2 Minutes)

If Render feels confusing, use Replit:

1. Go to **replit.com** and sign up with Google.
2. Click **Create** → **Import from GitHub**.
3. Paste your GitHub repo URL.
4. Replit auto-detects Python.
5. In the **Shell** (bottom panel), type:
   ```bash
   pip install -r requirements.txt
   python init_db.py
   python app.py
   ```
6. Click the green **Run** button.
7. Replit gives you a live URL instantly: `https://dramaforge.yourname.repl.co`

**Downside:** Replit free tier shows a "Powered by Replit" banner and sleeps after inactivity.

---

## YOUR ACTION ITEMS RIGHT NOW

1. [ ] Create GitHub account (1 min)
2. [ ] Upload the `dramaforge` folder to the new repo (2 min)
3. [ ] Create Render account with GitHub (1 min)
4. [ ] Connect repo and click Deploy (1 min)
5. [ ] Wait 2 min for green checkmark
6. [ ] Open your public link and test it
7. [ ] Share the link with 3 friends to keep the server awake

**Total time to live website: 7 minutes.**
