# DramaForge AI Studio

A complete, all-in-one web application to create AI-generated short dramas (vertical 9:16 episodes). 
**No API keys required.** Everything runs through free Pollinations.ai endpoints.

## What It Does

- **Script AI** — generates dramatic episode scripts via Pollinations text model
- **Character Lock** — generates consistent character portraits using controlled seeds + prompt tokens
- **Scene Builder** — generates scene images auto-injected with character tokens for consistency
- **Video Composer** — client-side Canvas engine with Ken Burns animation, text overlays, and real WebM export via MediaRecorder
- **Voice Preview** — browser-native Speech Synthesis reads your scene voice text during preview
- **Public Gallery** — publish episodes so anyone can watch
- **Admin Dashboard** — stats, users, projects

## Two Links

| URL | Role | Access |
|-----|------|--------|
| `/` | **Public** | Anyone can browse published dramas and watch episodes |
| `/admin` | **Admin** | Stats, user table, project monitoring |

Default admin login: `admin` / `admin123`

## Quick Start (Local)

```bash
cd dramaforge
pip install -r requirements.txt
python init_db.py   # creates database + admin user
python app.py       # runs on http://0.0.0.0:5000
```

Then open:
- Public site: `http://127.0.0.1:5000/`
- Admin panel: `http://127.0.0.1:5000/admin`  (login first with admin/admin123)
- Creator studio: `http://127.0.0.1:5000/studio`

## Deploy to Render (Free Public Links)

1. Push this `dramaforge/` folder to a GitHub repository.
2. Go to [render.com](https://render.com) → **New Web Service**.
3. Connect your GitHub repo, set:
   - **Runtime:** Python 3
   - **Build Command:** `pip install -r requirements.txt && python init_db.py`
   - **Start Command:** `gunicorn -w 4 -b 0.0.0.0:10000 app:app`
   - **Plan:** Free
4. Click **Deploy**.
5. Render gives you two permanent public links (one domain). Same paths apply:
   - `https://your-service.onrender.com/` → Public Gallery
   - `https://your-service.onrender.com/admin` → Admin Dashboard

## How to Create a Drama (End-to-End)

1. **Register** at `/register` and log in.
2. Go to **Studio** → **New Project**. Fill title, genre, concept, episode count.
3. In your project page:
   - **Add Characters** → enter name + visual tokens + seed → click Generate Portrait. The seed locks the face across all future scenes.
   - Open **Episode 1**.
4. In the Episode Builder:
   - Click **AI Write** to generate a script, or paste your own.
   - Click **+ Add Scene** → describe the shot → **Generate Scene Image**. The app injects character tokens automatically.
   - Add text overlay and voice text for each scene.
5. In the **Video Composer** (right column):
   - Click **Preview** to watch with Ken Burns + TTS.
   - Click **Export MP4** to record a real WebM video file (silent). Combine with music in CapCut, or record the preview tab with OBS to capture TTS audio.
6. Click **Publish** on the episode to make it visible on the public gallery.

## Architecture

- **Backend:** Flask + SQLite (zero-config database)
- **AI Layer:** Pollinations.ai proxy (text + image generation, no API key)
- **Frontend:** Vanilla JS + HTML Canvas (no React build step)
- **Video Export:** HTML5 Canvas `captureStream()` + `MediaRecorder`
- **Character Consistency:** Stored `seed` value + stored `prompt_tokens` prepended to every scene prompt

## Files

```
dramaforge/
  app.py              # Flask backend, all routes, Pollinations proxy
  init_db.py          # Database bootstrap + admin user
  requirements.txt    # Flask, requests, gunicorn, werkzeug
  templates/
    base.html         # Dark layout, responsive nav
    index.html        # Public gallery
    login.html        # Login / Register
    studio.html       # Creator dashboard
    project.html      # Character generator + episode grid
    episode.html      # Script AI, scene builder, canvas composer
    admin.html        # Stats + tables
    watch.html        # Public episode viewer
  static/
    uploads/          # Generated portraits, scenes, exported videos
```

## Security Notes

- Change `admin123` immediately after first deploy.
- Set `SECRET_KEY` environment variable in production (default dev key is in `app.py` for local use).
- Pollinations is free but rate-limited; for heavy production use, add a Midjourney/Stable Diffusion API key and swap the proxy routes in `app.py`.

## License

Built for creators. Use it, fork it, deploy it, monetize your dramas.
