# DramaForge Publishing Guide
## How to Publish Your AI Short Dramas — Officially & For Free

This guide covers every platform that pays or promotes short-form vertical dramas (9:16, 45–90 seconds per episode).

---

## BEFORE YOU PUBLISH: The Checklist

- [ ] **Episodes 1–3 are your hook** — they must end on a hard cliffhanger
- [ ] **Text overlays are readable on mobile** — font size 72pt minimum in CapCut
- [ ] **Exported video is vertical 1080×1920** (9:16)
- [ ] **Episode length: 55–75 seconds** — algorithm sweet spot
- [ ] **Music is royalty-free or AI-generated** — no copyright strikes
- [ ] **Title + hashtag formula ready** — see below

---

## THE FREE PLATFORMS (No Upfront Cost)

### 1. TikTok
**Why:** Largest organic reach for short drama. Creator Fund pays $0.02–$0.04 per 1,000 views in eligible countries.

**Setup:**
1. Create a TikTok Business account (free).
2. Post Episodes 1–3 as individual videos. **Hook:** Start with the most dramatic 3 seconds (a slap, a reveal, a betrayal).
3. End every video with: *"Episode 2 in bio"* or a pinned comment: *"Full series link in bio."*
4. In your bio, add a Linktree or Stan Store link pointing to:
   - Your Netshort/ReelShort profile (if accepted)
   - Your YouTube channel with full episodes
   - Your Patreon for early access

**Hashtag formula per post:**
```
#shortdrama #reels #kdrama #verticalseries #episode1 #viral #fyp
#revengedrama #powermove #mustwatch #trending
```

**Post schedule:** 1 episode per day at 7 PM–9 PM local time. Never batch-drop.

---

### 2. YouTube Shorts
**Why:** YouTube pays the best long-term via AdSense. A 1M-view Short earns roughly $1,500–$4,000 depending on RPM.

**Setup:**
1. Create a YouTube channel. Enable monetization once you hit 1,000 subs + 10M Shorts views (or 4,000 watch hours).
2. Upload full episodes as **YouTube Shorts** (under 60 seconds).
3. Create a **regular YouTube video** (not Short) that is a 10-minute compilation of Episodes 1–10. This earns higher AdSense RPM than Shorts.
4. Title formula: `"CRY FOR LOSING ME | Ep 1 | She Married the Wrong Man...and Became Untouchable"`
5. Description: Paste the episode script + links to Episode 2 + your Patreon/Netshort.
6. Tags: `short drama, vertical series, revenge drama, female lead, plot twist`

**Monetization path:**
- Shorts AdSense (after eligibility)
- Channel memberships ($4.99/mo for "early episode access")
- Super Thanks (fans tip per video)

---

### 3. Instagram Reels
**Why:** Reels monetization (Bonus program) pays per view in some regions. Also drives Link-in-bio traffic.

**Setup:**
1. Convert to a Creator account.
2. Post Episodes 1–3 as Reels. **Critical:** Use Instagram's native text tool for captions — the algorithm favors it.
3. Use 3–5 hashtags max (Instagram penalizes spam). Pick from:
   `#shortdrama #reelskdrama #verticalstory #dramatiktok`
4. Share to Stories with a "Swipe up" or link sticker to Episode 4+.
5. Go Live after posting Episode 3 to answer "What happens next?!" — drives massive engagement.

---

### 4. Facebook Reels
**Why:** Facebook monetizes Reels via in-stream ads and the Reels Play bonus program (invite-only but high payout).

**Setup:**
1. Upload the same vertical videos to Facebook Reels.
2. Join the **Reels Play Bonus Program** (apply in Creator Studio).
3. Cross-post from Instagram automatically.

---

### 5. Patreon / Ko-fi (Direct Fan Payment)
**Why:** Zero algorithm dependency. Fans pay you directly.

**Setup:**
1. Create a Patreon (free to start).
2. Tiers:
   - **$3/mo:** Episodes 7 days early
   - **$7/mo:** Behind-the-scenes AI prompts + character portrait packs
   - **$15/mo:** Vote on next plot twist + name a background character
3. Link in every video bio and pinned comment.

---

## THE OFFICIAL SHORT-DRAMA PLATFORMS (Apply as Creator)

These platforms **pay you per view** and promote your series to millions of users. They are the "Netflix of short drama."

### A. Netshort (https://netshort.com)
**Model:** Revenue share per minute watched. Users pay subscription; you get a cut.

**How to apply:**
1. Go to Netshort.com → Scroll to footer → "Creator Center" or "Submit Content."
2. Fill the creator application with:
   - Series title + logline (1 sentence)
   - Episode count + total runtime
   - Genre tags
   - Link to your pilot episode (upload to a private YouTube or Vimeo link)
3. Wait 5–10 business days for approval.
4. Once accepted, upload all 48 episodes via their CMS. They handle translation, dubbing, and global distribution.

**Tips:**
- Netshort prefers **completed series** (all episodes ready). Apply after you finish Episode 48.
- They love "revenge + power reversal" and "contract marriage" tropes. Lead with those keywords.

---

### B. ReelShort (https://reelshort.com)
**Model:** Pay-per-episode or subscription revenue share. Very aggressive user acquisition (you see their ads everywhere).

**How to apply:**
1. Email **content@reelshort.com** or find their "Become a Creator" page.
2. Submit a pitch deck with:
   - Title, genre, episode count
   - Character one-sheets
   - Script for Episodes 1, 10, 25, and 48 (show arc)
   - 3 sample episodes as video files
3. They often reply within 7 days.

**Tips:**
- ReelShort invests in marketing your series if the pilot tests well (they run ads). This is how *Fated to My Forbidden Alpha* became a global hit.
- Their audience is **primarily US female 25–45**. Adjust your title and cover image accordingly.

---

### C. DramaBox / FlexTV / Kalos TV
These are the emerging competitors to ReelShort. Same model.

| Platform | How to Apply | Notes |
|----------|-------------|-------|
| **DramaBox** | Creator portal at dramabox.com | Strong in Southeast Asia |
| **FlexTV** | Email in footer or app store page | Aggressive influencer marketing |
| **Kalos TV** | kalostv.com → Creator | Newer, less saturated |
| **ShortTV** | shorttv.live | Focus on global markets |
| **GoodShort** | goodshort.com | Part of the NewReading network |

**Bulk application strategy:**
1. Create one standard pitch deck (PDF, 8–10 slides).
2. Email it to all 6 platforms simultaneously.
3. Negotiate the best revenue share (usually 10–20% of net revenue).

---

### D. Kindle Vella (Written Version)
**Why:** Amazon pays you per "episode read" (first 3 episodes free, then tokens).

**How:**
1. Go to [kdp.amazon.com](https://kdp.amazon.com) → Kindle Vella.
2. Publish your scripts as written episodes (600–5,000 words each).
3. Readers buy tokens to unlock episodes. Amazon pays roughly $0.004 per token.
4. A 48-episode series with 10,000 readers = $1,900–$5,000.

**Pro move:** Publish the written version **simultaneously** with the video version. Some readers discover you on Vella, then watch on TikTok.

---

## THE UPLOAD WORKFLOW (Step-by-Step)

### Day 1–3: Soft Launch (Free Hook)
| Platform | Content | CTA |
|----------|---------|-----|
| TikTok | Episodes 1–3 | "Ep 4 in bio" |
| YouTube Shorts | Episodes 1–3 + compilation trailer | "Subscribe for daily drops" |
| Instagram Reels | Episodes 1–3 | "Link in bio for full series" |

### Day 4–7: Build Audience
- Reply to every comment with a teaser: *"Episode 5 is when she realizes he was the villain all along."
- Go Live for 5 minutes after each drop.
- Create a "Scene Breakdown" post (image carousel) explaining the AI creation process — this performs extremely well.

### Day 8+: Monetization Layer
- Add Patreon link to all bios.
- Apply to Netshort / ReelShort with your now-proven audience numbers (screenshot your TikTok analytics).
- Once accepted on a platform, edit your bio links to point there instead of Patreon.

---

## THE MONEY MATH (Realistic Estimates)

| Revenue Stream | 10K Views | 100K Views | 1M Views |
|---------------|-----------|------------|----------|
| TikTok Creator Fund | $0.20 | $2.00 | $20–$40 |
| YouTube Shorts AdSense | $5–$15 | $50–$150 | $500–$1,500 |
| YouTube Long-form AdSense | $30–$80 | $300–$800 | $3,000–$8,000 |
| Patreon (50 fans @ $5) | $250/mo | $250/mo | $250/mo |
| Netshort / ReelShort rev-share | $5–$20 | $100–$500 | $2,000–$10,000 |
| Kindle Vella | $5–$15 | $50–$150 | $500–$2,000 |

**Reality check:** The real money is in **owning the IP**. If one of your series hits, you can:
- License it for foreign-language dubbing ($5K–$50K upfront)
- Sell NFTs of character portraits (niche but real)
- Option the script to a traditional studio (ReelShort is already doing this)

---

## TITLE + THUMBNAIL FORMULA

### Title Structure (Copy this exactly)
```
[EMOTION WORD] + [CONFLICT] + [STAKES] + | Ep [N]
```

Examples that work:
- `"CRY FOR LOSING ME | Ep 1 | She Was His Shield—Until He Threw Her to the Wolves"`
- `"THE GHOST YOU WORE | Ep 12 | The Dress That Killed Her Was Woven by His Hands"`
- `"Marry the Cripple, Rule the World | Ep 7 | The Wedding Nobody Wanted"`

### Thumbnail Rules
- **Face takes up 60% of the frame** — eyes looking directly at camera or looking up (power dynamic)
- **Color contrast:** Dark background + one bright accent color (red lip, gold thread, blue light)
- **Text:** 3–5 words MAX. White font with black outline.
- **Expression:** Anguish, shock, or cold determination. Never smiling.

---

## QUICK REFERENCE: LINKS TO APPLY

| Platform | URL | Application Method |
|----------|-----|-------------------|
| Netshort | https://netshort.com | Creator Center in footer |
| ReelShort | https://reelshort.com | content@reelshort.com |
| DramaBox | https://dramabox.com | Creator portal |
| FlexTV | https://flextv.cc | Email or in-app |
| ShortTV | https://shorttv.live | Creator page |
| GoodShort | https://goodshort.com | Email |
| Kindle Vella | https://kdp.amazon.com | Direct upload (no approval) |
| Patreon | https://patreon.com | Instant setup |

---

## FINAL TIP: THE 48-HOUR RULE

On every platform, **the first 48 hours determine everything.**

- Post at the same time daily.
- Reply to every comment in the first 2 hours.
- Share to Stories / Community tab immediately after posting.
- If a video hits 10K views in 24 hours, immediately drop a "Part 2" or "Behind the Scenes" to ride the wave.

**Algorithm favor = consistency + engagement velocity.** AI gives you the speed to post daily. Use it.
